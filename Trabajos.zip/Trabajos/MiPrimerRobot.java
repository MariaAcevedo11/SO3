// Ejercicio 4

package Trabajos; 
import kareltherobot.*;
import java.awt.Color;

// Clase personalizada de robot que corre en su propio hilo
class MiPrimerRobot extends Robot implements Runnable, Directions {
    
    public MiPrimerRobot(int street, int avenue, Direction direction, int beeps) {
        super(street, avenue, direction, beeps);
        World.setupThread(this); // Muy importante para el paralelismo
    }

    public MiPrimerRobot(int street, int avenue, Direction direction, int beeps, Color color) {
        super(street, avenue, direction, beeps, color);
        World.setupThread(this);
    }

    // Movimiento que hará el robot
    public void race() {

        move();
        pickBeeper();
        move();
        move();
        turnLeft();
        move();
        move();
        pickBeeper();
        move();
        turnLeft(); turnLeft(); turnLeft(); 
        move();
        turnLeft();
        move();
        move();
        pickBeeper();
        move();
        move();
        move();
        pickBeeper();
        move();
        turnLeft(); turnLeft(); turnLeft();
        move();
        pickBeeper();
        move();
        move();
        turnLeft();
        move();
        move();
        pickBeeper();
        move();
        move();
        pickBeeper();
        move();
        move();
        pickBeeper();
        move();
        move();
        move();
        turnLeft();
        move();
        move();
        move();
        pickBeeper();
        move();
        move();
        turnLeft(); turnLeft(); turnLeft();
        move();
        pickBeeper();
        move();
        move();
        turnLeft(); turnLeft(); turnLeft();
        move();
        move();
        turnLeft();
        move();
        move();
        pickBeeper();
        move();
        turnLeft(); turnLeft(); turnLeft();
        move();
        turnLeft();
        move();
        move();
        pickBeeper();
        move();
        turnLeft(); turnLeft(); turnLeft();
        move();
        turnLeft();
        move();
        move();
        move();
        pickBeeper();
        move();
        move();
        move();
        turnLeft(); turnLeft(); turnLeft();
        move();
        move();
        pickBeeper();
        turnLeft();
        turnLeft();
        move();
        move();
        turnLeft();
        turnOff();
    }

    public void run() {
        race();
    }

    public static void main(String[] args) {
        World.readWorld("MetroMed.kwld");
        World.setVisible(true); 

        // Creamos dos robots
        Racer lineA = new Racer(1, 10, East, 0, Color.BLUE); // Normal (color default)
        Racer lineB = new Racer(3, 1, East, 0, Color.GREEN); // Azul directamente usando el constructor

        new Thread(lineA).start();
        new Thread(lineB).start();// Los robots ya corren paralelamente por setupThread()
    }
}




